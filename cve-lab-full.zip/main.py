from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os, json
from lab_launcher import launch_cve_lab

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    with open("cves/CVE-2022-22965/meta.json") as f:
        cve = json.load(f)
    with open("cves/CVE-2022-22965/exploit.py") as f:
        code = f.read()
    return templates.TemplateResponse("cve_detail.html", {"request": request, "cve": cve, "exploit_code": code})

@app.post("/cve/{cve_id}/launch")
def launch(cve_id: str):
    return {"lab_url": launch_cve_lab(cve_id)}
