import docker
client = docker.from_env()

def launch_cve_lab(cve_id):
    image_tag = f"cve-{cve_id.lower()}"
    container = client.containers.run(
        image=image_tag,
        detach=True,
        ports={'8080/tcp': ('0.0.0.0', None)},
        name=f"lab-{cve_id}",
        remove=True
    )
    container.reload()
    port = container.attrs['NetworkSettings']['Ports']['8080/tcp'][0]['HostPort']
    return f"http://your-public-ip:{port}"
