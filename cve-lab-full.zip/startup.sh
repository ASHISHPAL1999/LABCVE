#!/bin/bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
docker build -t cve-cve-2022-22965 ./cves/CVE-2022-22965
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
