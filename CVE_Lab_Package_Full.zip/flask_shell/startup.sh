#!/bin/bash
cd /opt/app/flask_shell
pip3 install flask
python3 app.py
