
from flask import Flask, render_template_string, request, jsonify
import subprocess

app = Flask(__name__)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Web Shell Terminal</title>
    <style>
        body { background-color: #000; color: #0f0; font-family: monospace; padding: 20px; }
        input[type=text] { width: 80%%; background-color: #222; color: #0f0; border: none; padding: 10px; }
        button { background: #0f0; color: #000; padding: 10px; border: none; }
        pre { background: #111; padding: 20px; }
    </style>
</head>
<body>
    <h1>Web Shell (Container Lab)</h1>
    <form method="POST">
        <input type="text" name="cmd" placeholder="Enter shell command" autofocus>
        <button type="submit">Run</button>
    </form>
    {% if output %}
    <h3>Output:</h3>
    <pre>{{ output }}</pre>
    {% endif %}
</body>
</html>
'''

@app.route("/", methods=["GET", "POST"])
def shell():
    output = ""
    if request.method == "POST":
        cmd = request.form["cmd"]
        try:
            output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=10)
            output = output.decode("utf-8")
        except subprocess.CalledProcessError as e:
            output = e.output.decode("utf-8")
        except Exception as e:
            output = str(e)
    return render_template_string(HTML_TEMPLATE, output=output)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
