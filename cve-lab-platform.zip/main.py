from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from lab_launcher import launch_cve_lab
import os, json

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

def load_all_cves():
    cve_list = []
    for cve_dir in os.listdir("cves"):
        meta_path = os.path.join("cves", cve_dir, "meta.json")
        if os.path.exists(meta_path):
            with open(meta_path) as f:
                data = json.load(f)
                cve_list.append(data)
    return sorted(cve_list, key=lambda x: x["year"], reverse=True)

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "cves": load_all_cves()})

@app.get("/cve/{cve_id}", response_class=HTMLResponse)
def detail(request: Request, cve_id: str):
    with open(f"cves/{cve_id}/meta.json") as f:
        cve = json.load(f)
    with open(f"cves/{cve_id}/exploit.py") as f:
        exploit_code = f.read()
    return templates.TemplateResponse("cve_detail.html", {"request": request, "cve": cve, "exploit_code": exploit_code})

@app.post("/cve/{cve_id}/launch")
def launch(cve_id: str):
    url = launch_cve_lab(cve_id)
    return {"status": "launched", "lab_url": url}
